# P4LAB1A_SimmonsKimberly.py
# This program draws a square and a triangle using loops.

import turtle

# Create turtle screen and turtle object
wn = turtle.Screen()
wn.bgcolor("lightblue")

t = turtle.Turtle()
t.pensize(3)
t.color("blue")

# Draw a square using a for loop
for _ in range(4):
    t.forward(100)
    t.left(90)

# Move turtle to a different position for triangle
t.penup()
t.goto(150, 0)
t.pendown()
t.color("green")

# Draw a triangle using a while loop
sides = 0
while sides < 3:
    t.forward(100)
    t.left(120)
    sides += 1

# Hide turtle and finish
t.hideturtle()
wn.mainloop()
