# P4LAB1B_SimmonsKimberly.py
# This program draws the initials "K" and "S" using turtle graphics.

import turtle

# Set up turtle screen
wn = turtle.Screen()
wn.bgcolor("white")

# Create turtle object
t = turtle.Turtle()
t.pensize(5)
t.color("purple")

# Draw the letter K
t.penup()
t.goto(-100, 0)
t.pendown()
t.left(90)
t.forward(100)
t.backward(50)
t.right(45)
t.forward(70)
t.backward(70)
t.right(90)
t.forward(70)

# Move to draw S
t.penup()
t.goto(50, 50)
t.setheading(0)  # Face right
t.pendown()

# Draw the letter S
t.forward(50)
t.circle(25, 180)
t.forward(50)
t.circle(-25, 180)
t.forward(50)

# Hide turtle and finish
t.hideturtle()
wn.mainloop()
